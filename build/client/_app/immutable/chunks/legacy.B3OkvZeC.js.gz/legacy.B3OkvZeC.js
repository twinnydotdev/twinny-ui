import { M as enable_legacy_mode_flag } from "./runtime.BnxtgvYn.js";
enable_legacy_mode_flag();
