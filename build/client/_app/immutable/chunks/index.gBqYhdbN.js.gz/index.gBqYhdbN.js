const URL_VSCODE_MARKETPLACE = "https://marketplace.visualstudio.com/items?itemName=rjmacarthy.Twinny";
const URL_DOCS = "https://docs.twinny.dev";
const URL_GITHUB = "https://github.com/twinnydotdev";
const URL_TWINNYDOTDEV = "https://x.com/twinnydotdev";
export {
  URL_GITHUB as U,
  URL_VSCODE_MARKETPLACE as a,
  URL_DOCS as b,
  URL_TWINNYDOTDEV as c
};
