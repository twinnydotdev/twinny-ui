import { b } from "../chunks/entry.Ds2mMouq.js";
export {
  b as start
};
